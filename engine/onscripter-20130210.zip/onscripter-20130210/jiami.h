void onsLocaleInit();
int onsLocaleIsTwoByte(unsigned char x);
unsigned short onsLocaleConv( unsigned short in );
unsigned short ons_get_encryption_short(unsigned short t);
unsigned short ons_get_unencryption_short(unsigned short t);
const int data_len = 0xfefe - 0x8140 + 1;
